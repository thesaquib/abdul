<?php
//get data from form
$name = $_POST["name"];
$email = $_POST["email"];
$subject = $_POST["subject"];
$message = $_POST["message"];

$to = "mohammed.abdul@panzertechnologies.com";

$subject = "Enquiry from M One Realty";
$txt = "Name = " . $name . "\r\n Email =" . $email . " \r\n Subject =" . $subject . "
\r\n Message = " . $message;

$headers = "From: abdulsaquib150@gmail.com" . "\r\n";
if ($email != NULL) {
    mail($to, $subject, $txt, $headers);
    //redirect
    header("Location:thankyou.html");
}